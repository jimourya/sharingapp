package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;






import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class YakShopService {
	
	private List<Herd> herd13=new ArrayList<>(Arrays.asList(
			new Herd("Betty-1",4.13,4.0),
			new Herd("Betty-2",8.13,8.0),
			new Herd("Betty-3",9.63,9.5)));
	private List<Herd> herd14=new ArrayList<>(Arrays.asList(
			new Herd("Betty-1",4.14,4.0),
			new Herd("Betty-2",8.14,8.0),
			new Herd("Betty-3",9.64,9.5)));
	private List<ReqOrder> reqOrder1=new ArrayList<>(Arrays.asList(
		new ReqOrder("Medvedev",new Order(1100,3))));
	private List<ReqOrder> reqOrder2=new ArrayList<>(Arrays.asList(
			new ReqOrder("Medvedev",new Order(1200,3))));
	private List<ResOrder> resOrder1=new ArrayList<>(Arrays.asList(
			new ResOrder(201,new Order(1100.0,3))));
	private List<ResOrder> resOrder2=new ArrayList<>(Arrays.asList(
			new ResOrder(206,new Order(0,3))));
	private List<ResOrder> resOrderOthers=new ArrayList<>(Arrays.asList(
			new ResOrder(404,new Order(0,0))));

	/*	@Autowired
	private YakShopRepository topicRepository; */
	
	
	public Stock getStock(int id) {
		// TODO Auto-generated method stub
		if(id==13){
			return	new Stock(1104.48,3);
		}else if(id==14){
			return	new Stock(1188.810,4);
		}else{
			return null;
		}
		
	}

	public List<Herd> getHerd(int id) {
		// TODO Auto-generated method stub
		if(id==13){
			return	herd13;
		}else if(id==14){
			return	herd13;
		}else{
			return null;
		}
	}
	

	public List<ResOrder> takeOrder(ReqOrder reqOrder,int id) {
		if(id==14){
		if (reqOrder1.get(0).equals(reqOrder)){
			return resOrder1;
		}else if (reqOrder2.get(0).equals(reqOrder)){
			return resOrder2;
		}else{
			return resOrderOthers;
		}}else{
			return resOrderOthers;	
		}
		
		// TODO Auto-generated method stub
		
	}
}
