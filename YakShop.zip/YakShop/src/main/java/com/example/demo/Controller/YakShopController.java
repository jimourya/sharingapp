package com.example.demo.Controller;









import java.io.FileInputStream;

//import java.io.s

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.*;
import com.example.demo.ServiceImpl.YakShopServiceImpl;
import com.example.demo.dtos.*;
@Configuration
@EnableAutoConfiguration
@ComponentScan
@RestController

public class YakShopController {
	
	private YakShopService yakShopService=new  YakShopServiceImpl();;
	 FileInputStream in = null;
	 
		@RequestMapping(method=RequestMethod.POST,value="/yak-shop/herds/{fullpath}")
		  @Consumes("application/xml")
		@Produces("application/xml")	
		
			public  void ReadXMLFile(@PathVariable String fullpath)
			{
				String url="http://localhost:8080/yak-shop/herds/";
			
			  
			    StringBuilder sb = new StringBuilder();
	    
			        try {
			        	in = new FileInputStream(fullpath);	
					         
			        
			        	yakShopService.saveData( in);
			        	
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
			 }

	
	@RequestMapping(method=RequestMethod.GET,value="/yak-shop/stock/{id}")
	public Stock getStock(@PathVariable int id){
		return yakShopService.getStock(id);
	}
	@RequestMapping(method=RequestMethod.GET,value="/yak-shop/herd/{id}")
	public List<Herd> getHerd(@PathVariable int id){
		return yakShopService.getHerd(id);
	}
	@RequestMapping(method=RequestMethod.POST,value="/yak-shop/order/{id}")
	public List<ResOrder> takeOrder(@RequestBody ReqOrder reqOrder,@PathVariable int id){
		return yakShopService.takeOrder(reqOrder,id);
	}
}
