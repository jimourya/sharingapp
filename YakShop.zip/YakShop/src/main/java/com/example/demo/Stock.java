package com.example.demo;

public class Stock {
	private	double milk;
	public double getMilk() {
		return milk;
	}
	public void setMilk(double milk) {
		this.milk = milk;
	}
	public int getSkin() {
		return Skin;
	}
	public void setSkin(int skin) {
		Skin = skin;
	}
	
	private int Skin;
	
	public Stock(double milk, int skin) {
		super();
		this.milk = milk;
		Skin = skin;
		//this.customer = customer;
	}
	
}
