package com.example.demo.dtos;

public class test {

}
