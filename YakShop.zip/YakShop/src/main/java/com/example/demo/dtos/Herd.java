package com.example.demo.dtos;

public class Herd {
	private String name;
	private double age;
	private double ageLastShaved;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAge() {
		return age;
	}

	public void setAge(double age) {
		this.age = age;
	}

	public double getAgeLastShaved() {
		return ageLastShaved;
	}

	public void setAgeLastShaved(double ageLastShaved) {
		this.ageLastShaved = ageLastShaved;
	}

	public Herd(String name, double age, double ageLastShaved) {
		super();
		this.name = name;
		this.age = age;
		this.ageLastShaved = ageLastShaved;
	}

}

