package com.example.demo;




import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class YakShopController {
	@Autowired
	private YakShopService yakShopService;
	
	@RequestMapping(method=RequestMethod.GET,value="/yak-shop/stock/{id}")
	public Stock getStock(@PathVariable int id){
		return yakShopService.getStock(id);
	}
	@RequestMapping(method=RequestMethod.GET,value="/yak-shop/herd/{id}")
	public List<Herd> getHerd(@PathVariable int id){
		return yakShopService.getHerd(id);
	}
	@RequestMapping(method=RequestMethod.POST,value="//yak-shop/order/{id}")
	public List<ResOrder> takeOrder(@RequestBody ReqOrder reqOrder,@PathVariable int id){
		return yakShopService.takeOrder(reqOrder,id);
	}
}
