package com.example.demo.dtos;

public class ResOrder {
	private Order order;

	public ResOrder(int status, Order order) {
		super();
		this.order = order;
		this.status = status;
	}

	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
}
