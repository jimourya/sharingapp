package com.example.demo;

public class IHerd {
	private String 	name;
	private	double age;
	private String sex;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAge() {
		return age;
	}
	public void setAge(double age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setAgeLastShaved(String sex) {
		this.sex = sex;
	}
	
	public IHerd(String name, double age, String sex) {
		super();
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	
}
