package com.example.demo;

public class ReqOrder {
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public ReqOrder(String customer, Order order) {
		super();
		this.customer = customer;
		this.order = order;
	}
	private	 String customer;
	private Order order;
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
}
