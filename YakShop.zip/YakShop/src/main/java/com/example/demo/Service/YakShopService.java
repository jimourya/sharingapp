package com.example.demo.Service;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dtos.*;
@Service
public interface YakShopService {
	
	public Stock getStock(int id);

	public List<Herd> getHerd(int id);

	public List<ResOrder> takeOrder(ReqOrder reqOrder, int id);

	public void saveData(FileInputStream in);

}
