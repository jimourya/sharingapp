package com.example.demo.Controller.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;

import com.example.demo.Controller.YakShopController;
import com.example.demo.Service.YakShopService;
import com.example.demo.ServiceImpl.YakShopServiceImpl;
import com.example.demo.dtos.*;

@RunWith(MockitoJUnitRunner.class)
@WebMvcTest(value = YakShopController.class, secure = false)
public class YakShopControllerTest {
	
	@MockBean
	    private static  YakShopService yakShopService;
	@InjectMocks
	private static  YakShopServiceImpl pcyakShopServiceImpl;
	FileInputStream in = null;
	@Mock 
	private	YakShopService pcyakShopService;
	//@PrepareForTest({ PcyakShopService.class })
	
	@Autowired
	private MockMvc mockMvc;
	private RequestBuilder requestBuilder;
	 /*   @Mock
	    private final ModelMap model=new ModelMap();*/ 

	 /*   @InjectMocks
	    private ApplicationContext applicationContext;
*/
	   private static MockHttpServletRequest request;
	    private static MockHttpServletResponse response;

	    private static YakShopController yakShopController;
	    @BeforeClass
	    public static void init() {

	           request = new MockHttpServletRequest();
	           response = new MockHttpServletResponse();           
	           yakShopController = new YakShopController();
	          yakShopService =new YakShopServiceImpl();
	    }  
  
		
///PcyakShopService mock =  org.mockito.Mockito.mock(YakShopServiceImpl.class);
		

	    List<Herd> herd14=new ArrayList<>(Arrays.asList(new Herd("Betty-1",4.14,4.0),
				new Herd("Betty-2",8.14,8.0),
				new Herd("Betty-3",9.64,9.5)));
	    private List<ReqOrder> reqOrder2=new ArrayList<>(Arrays.asList(
				new ReqOrder("Medvedev",new Order(1200,3))));
		private List<ResOrder> resOrder2=new ArrayList<>(Arrays.asList(
				new ResOrder(206,new Order(0,3))));
	    
	    private Stock stock;
	    @Autowired
	    private ReqOrder reqOrder;

		//String exampleCourseJson = "{\"name\":\"Spring\",\"description\":\"10 Steps\",\"steps\":[\"Learn Maven\",\"Import Project\",\"First Example\",\"Second Example\"]}";

	    @Before
	    public void setUp() {
	   	MockitoAnnotations.initMocks(this);
	    this.mockMvc = MockMvcBuilders
                .standaloneSetup( yakShopController).build();	     
	    }
	    @Test
		public void getHerd() throws Exception{
	    	pcyakShopService =  org.mockito.Mockito.mock(YakShopServiceImpl.class);
	    		    	/*Mockito.verify(mock).when(
	    	  			yakShopService.getHerd(14)).equals(herd14);*/
	    	when(pcyakShopService.getHerd(14)).thenReturn(herd14);
	    	assertEquals(pcyakShopService.getHerd(14), herd14);
	    	//  verify(pcyakShopService,times(1)).getHerd(14);
	    //	org.springframework.test.web.servlet.request..MockHttpServletRequestBuilder
			 requestBuilder = MockMvcRequestBuilders.get(
					"/yak-shop/herd/14").accept(
					MediaType.APPLICATION_JSON);

			MvcResult result = mockMvc.perform(requestBuilder).andReturn();

			System.out.println(result.getResponse());
			String expected = "[{name : Betty-1, age :4.14,ageLastShaved :4.0},{ name : Betty-2, age :8.14, ageLastShaved :8.0},{ name : Betty-3 , age :9.64, ageLastShaved :9.5}]";
			JSONAssert.assertEquals(expected, result.getResponse()
					.getContentAsString(), false);
	    	
	    }
  @Test
  public void ReadXMLFile() throws Exception{
	  String fullpath="herd.xml"; 
	 	in = new FileInputStream(fullpath);	
	 		
	  pcyakShopService =  org.mockito.Mockito.mock(YakShopServiceImpl.class);
    	/*Mockito.verify(mock).when(
			yakShopService.getHerd(14)).equals(herd14);*/
/*	  pcyakShopService.out = Mockito.spy(new PrintStream("expected command"));
	  verify(pcyakShopService.out,times(1)*/
	     // mock a call with an expected input
	     //when(pcyakShopService.out).println("expected command");
	 // assertTrue(check);
//when(pcyakShopService.saveData(in));
//verify(pcyakShopService,times(1)).saveData(in);
//	  assertEquals(pcyakShopService.saveData(in), void);
//	org.springframework.test.web.servlet.request..MockHttpServletRequestBuilder
	 
requestBuilder = MockMvcRequestBuilders.post(
	"/yak-shop/herds/herd.xml").accept(
	MediaType.APPLICATION_ATOM_XML);
//this.mockMvc.perform(MockMvcRequestBuilders.fileUpload("/sample/insertBoard.do"));

MvcResult result = mockMvc.perform(requestBuilder).andReturn();

response = result.getResponse();
//"{status :206,{milk :0,skin :3}}"
assertEquals(HttpStatus.OK.value(), response.getStatus());

/*
String expected = "";
JSONAssert.assertEquals(expected, result.getResponse()
	.getContentAsString(), false);*/

  }

 
  //Mockito PcyakShopService;
  @Test
  public void getStock() throws Exception{
	  stock =new  Stock(1188.810,4);
	  pcyakShopService =  org.mockito.Mockito.mock(YakShopServiceImpl.class);
	  pcyakShopServiceImpl=(YakShopServiceImpl) pcyakShopService;
	  when(pcyakShopServiceImpl.getStock(14)).thenReturn(stock);
	  assertEquals(pcyakShopService.getStock(14), stock);
	  //assertEquals(pcyakShopServiceImpl.getStock(14),stock);
	//  verify(pcyakShopServiceImpl,times(1)).getStock(new Integer(14));
	  
	/*  Mockito.verify(mock).when(
  			yakShopService.getStock(14)).equals(stock);*/
	//  assertEquals(yakShopService.getStock(14),yakShopService.);
	 /* yakShopService.getStock(14). when(mock).equals(yakShopService.getStock(14));
	  Mockito.verify(mock).RETURNS_MOCKS.equals(stock);*/
  //	org.springframework.test.web.servlet.request..MockHttpServletRequestBuilder
		 requestBuilder = MockMvcRequestBuilders.get(
				"/yak-shop/stock/14").accept(
				MediaType.APPLICATION_JSON);
		 String expected = "{milk :1188.81,skin :4}";
	//	  mockMvc.perform(requestBuilder).andExpect((ResultMatcher) jsonPath(expected));
		 
		
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		 response = result.getResponse();
		//assertEquals(HttpStatus.CREATED.value(), response.getStatus());
	/*	assertEquals("/yak-shop/stock/{14}",
				response.getHeader(HttpHeaders.AGE));*/
		System.out.println(result.getResponse());
		
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
  }

  @Test
  public void takeOrder() throws Exception{
	 	pcyakShopService =  org.mockito.Mockito.mock(YakShopServiceImpl.class);
    	/*Mockito.verify(mock).when(
			yakShopService.getHerd(14)).equals(herd14);*/
when(pcyakShopService.takeOrder(reqOrder2.get(0),14)).thenReturn(resOrder2);
//verify(pcyakShopService,times(1)).takeOrder(reqOrder2.get(0),14);
assertEquals(pcyakShopService.takeOrder(reqOrder2.get(0),14), resOrder2);

//boolean check=
//assertTrue(check);

//	org.springframework.test.web.servlet.request..MockHttpServletRequestBuilder
requestBuilder = MockMvcRequestBuilders.post(
	"/yak-shop/order/14").accept(
	MediaType.APPLICATION_JSON);

MvcResult result = mockMvc.perform(requestBuilder).andReturn();

System.out.println(result.getResponse());
String expected = "{milk :0,skin :3}";
//response = result.getResponse();
//"{status :206,{milk :0,skin :3}}"
assertEquals(HttpStatus.OK.value(), response.getStatus());
//JSONAssert.assertEquals(expected, result.getResponse()
//	.getContentAsString(), true);

  }
}
