package com.example.share.api;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Event")
public class Event {

	private int eId;
	private String eName;

	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	
	

}
