package com.example.share.Service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.share.api.Event;
import com.example.share.api.Order;
import com.example.share.repositary.OrderRepositary;

public class ItemService {
	@Autowired
	private OrderRepositary orderRepositary;
	private List<Event> l;


	public void addOrder(Event event) {
		// TODO Auto-generated method stub
		
	}

	public List<Event> getMasterOrder(String name) {
		// TODO Auto-generated method stub
		 l=new ArrayList<>();
		
		return l;
	}

	public List<Event> getEvent(String name) {
		// TODO Auto-generated method stub
		return null;
	} 
}
