package com.example.share.api;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="User")

public class User {

	
	public int getuId() {
		return uId;
	}
	public void setuId(int uId) {
		this.uId = uId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	private int uId;
	private String name;
	private String address;
	private String email;
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gId")
		private Group groupId;
	public Group getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId.setgId(groupId);
	}
	
}
