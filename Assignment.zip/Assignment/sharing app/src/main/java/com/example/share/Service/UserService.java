package com.example.share.Service;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.share.api.Order;
import com.example.share.api.User;
import com.example.share.repositary.GroupRepositary;
import com.example.share.repositary.OrderRepositary;
import com.example.share.repositary.UserRepositary;

public class UserService {
	@Autowired
	private UserRepositary userRepositary;
	private EntityManager entityManager;
	private List<User> l;

	public User getUser(String name) {
		// TODO Auto-generated method stub
		User user=userRepositary.findOne(name);
		return user;
	}

	/*public void addOrder(User user) {
		// TODO Auto-generated method stub
		
	}*/

	public List<User> getUserList(String name) {
		// TODO Auto-generated method stub
		
		User user=getUser(name);
		l= entityManager.createNamedQuery( "SELECT OBJECT(a) FROM User AS a WHERE a.gid = ?1").setParameter(1, user.getGroupId().getgId()).getResultList();
					
		return l;
	} 
}
