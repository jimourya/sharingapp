package com.example.share.Service;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.share.api.Event;
import com.example.share.api.Order;
import com.example.share.api.Owes;
import com.example.share.api.User;
import com.example.share.repositary.OrderRepositary;
import com.example.share.repositary.OwesRepositary;

public class OwesService {
	@Autowired
	private OwesRepositary owesRepositary;
	private EntityManager entityManager;
	@Autowired
	private UserService userService;
	
	private List<Event> l;


	public void addOwes(Event event) {
		// TODO Auto-generated method stub
		
		
	}
	@Autowired
	public void addOwes(HashMap hs,List<Order> o) {
		// TODO Auto-generated method stub
		Owes ow=new Owes();
		Order order;
		User user;
		List<User> u;
		Event e;
		int j=0;
		if(!hs.isEmpty()){
		
		Set<User> s=hs.keySet();
		if(s.stream().limit(s.size()).iterator().hasNext()){
			user=s.stream().limit(s.size()).iterator().next();
			e=(Event)o.get(j).geteId();
			
			u=userService.getUserList(user.getGroupId().getgName());
			int count =u.size();
			for( int k=0;k<count;k++){
			ow.setGuestId(u.get(k));
			ow.setHostId(user);
			ow.setEid(e);
			ow.setRepayment(((Integer)hs.get(user))/count);
			entityManager.persist(ow);
			
			}
			
		}
			j++;
		}
		
		}
		
	

	public List<Event> getMasterOrder(String name) {
		// TODO Auto-generated method stub
		 l=new ArrayList<>();
		
		return l;
	}

	public List<Event> getEvent(String name) {
		// TODO Auto-generated method stub
		return null;
	} 
}
