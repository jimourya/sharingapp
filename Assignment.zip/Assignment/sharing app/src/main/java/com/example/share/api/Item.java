package com.example.share.api;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Item")
public class Item {
	public Item(int iId, String iName, String iType,int Price) {
		super();
		this.iId = iId;
		this.iName = iName;
		this.iType = iType;
		this.Price=Price;
	}
	private int iId;
	private String iName;
	private String iType;
	private int Price;
	public int getiId() {
		return iId;
	}
	public void setiId(int iId) {
		this.iId = iId;
	}
	public String getiName() {
		return iName;
	}
	public void setiName(String iName) {
		this.iName = iName;
	}
	public String getiType() {
		return iType;
	}
	public void setiType(String iType) {
		this.iType = iType;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	
	

}
