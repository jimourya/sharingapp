package com.example.share.api;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Owes")
public class Owes {
private Integer OID;
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "gId")

private User hostId;
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "gId")

private User guestId;
@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "gId")

private Event eid;
private int repayment;
public Owes(){};
public Owes(int hostId,int guestId,int eId,int repayment){
	this.hostId.setuId(hostId);
	this.hostId.setuId(guestId);
	this.eid.seteId(eId);
	this.repayment=repayment;
}
public int getOID() {
	return OID;
}
public void setOID(int oID) {
	OID = oID;
}
public User getHostId() {
	return hostId;
}
public void setHostId(User hostId) {
	this.hostId = hostId;
}
public User getGuestId() {
	return guestId;
}
public void setGuestId(User guestId) {
	this.guestId = guestId;
}
public Event getEid() {
	return eid;
}
public void setEid(Event eid) {
	this.eid = eid;
}
public int getRepayment() {
	return repayment;
}
public void setRepayment(int repayment) {
	this.repayment = repayment;
}

}
