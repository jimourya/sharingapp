package com.example.share.Service;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.share.api.Event;
import com.example.share.api.Order;
import com.example.share.api.User;
import com.example.share.repositary.EventRepositary;
import com.example.share.repositary.OrderRepositary;

public class OrderService {
	@Autowired
	private OrderRepositary orderRepositary;
	@Autowired
	private EventRepositary eventRepositary;
	private EntityManager entityManager;
	private List<Order> l;

	UserService us= new UserService();
	OwesService ows= new OwesService();
	User user;
	HashMap h;
	public Order getOrder(String id) {
		// TODO Auto-generated method stub
		return orderRepositary.findOne(id);
	}

	public void addOrder(Order order) {
		// TODO Auto-generated method stub
		orderRepositary.save(order);
		
		
	}
	public List<Order> getOrderByEvent(String name) {
		// TODO Auto-generated method stub
		 h=new HashMap();
		Event event=eventRepositary.findOne(name);
		l=entityManager.createNamedQuery("SELECT OBJECT(a) FROM Order AS a WHERE a.eid = ?1").setParameter(1, event.geteId()).getResultList();
for (int i=0;i<l.size();i++){
	Integer price=(Integer)h.get(l.get(i).getuId());
	if(price==null||price==0){
	h.put(l.get(i).getuId(), l.get(i).getiId().getPrice());
	}else{
		price=price+l.get(i).getiId().getPrice();
	}
}
ows.addOwes(h,l);
return l;
	
	
	

		

	} 

	public List<Order> getMasterOrder(String name) {
		// TODO Auto-generated method stub
		 l=new ArrayList<>();
		
		return l;
	} 
}
