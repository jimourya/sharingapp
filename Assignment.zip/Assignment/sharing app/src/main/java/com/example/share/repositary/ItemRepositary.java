package com.example.share.repositary;



import org.springframework.data.repository.CrudRepository;

import com.example.share.api.*;

public interface ItemRepositary extends CrudRepository<Item,String>{

	
}
