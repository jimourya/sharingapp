package com.example.share.api;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Order")
public class Order {

	  
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "iId")
	private Item item;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "eId")
	private Event eId;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "uId")
	private User uId;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gId")
	private Group gId;
	
	private int oId;
	
	
	
	

	public Order(int oId, int uId,int gId ,int iId,int eId) {
		super();
		this.oId = oId;
		this.uId.setuId(uId) ;
		this.gId.setgId(gId);
		this.item.setiId(iId);
		this.eId.seteId(eId);
	}

	public int getoId() {
		return oId;
	}

	public void setoId(int oId) {
		this.oId = oId;
	}

	public User getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId.setuId(uId);
	}

	public Group getgId() {
		return gId;
	}

	public void setgId(int gId) {
		this.gId.setgId(gId);
	}

	public Item getiId() {
		return item;
	}

	public void setiId(int iId) {
		this.item.setiId(iId);
	}

	public Event geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId.seteId(eId);
	}


}
