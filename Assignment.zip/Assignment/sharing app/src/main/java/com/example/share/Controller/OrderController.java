package com.example.share.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.share.Service.EventService;
import com.example.share.Service.OrderService;
import com.example.share.Service.UserService;
import com.example.share.api.Event;
import com.example.share.api.Order;
import com.example.share.api.User;

@Configuration
@EnableAutoConfiguration
@ComponentScan	
@RestController
public class OrderController {
	
	@Autowired
	private OrderService orderService; 
	@Autowired
	private UserService userService;
	@Autowired
	private EventService eventService;
	
	@RequestMapping(method=RequestMethod.POST,value="/Order")
	public void addBillPayIndividual(@RequestBody Order order){ 
		orderService.addOrder(order);
	}
	@RequestMapping(method=RequestMethod.POST,value="/Orders")
	public void adddBillPayAllInGroup(@RequestBody Order order){
		orderService.addOrder(order);
	}
	
	
	@RequestMapping("/User/{name}")
	public List<User> getMasterUser(@PathVariable String name){
		return userService.getUserList(name);
	}
	@RequestMapping("/Event")
	public Event getEvent(@PathVariable String name){
		return eventService.getEvent(name);
	}
	
}
