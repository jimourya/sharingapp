package com.example.share.api;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Group")
public class Group {
	public Integer getgId() {
		return gId;
	}
	
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	private Integer gId;
	private String gName;
	public void setgId(Integer gId) {
		// TODO Auto-generated method stub
		this.gId = gId;
	} 

	
}
