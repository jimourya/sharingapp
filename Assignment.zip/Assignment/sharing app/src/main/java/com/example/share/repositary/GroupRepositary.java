package com.example.share.repositary;



import org.springframework.data.repository.CrudRepository;

import com.example.share.api.*;

public interface GroupRepositary extends CrudRepository<Group,Integer>{

	
}
