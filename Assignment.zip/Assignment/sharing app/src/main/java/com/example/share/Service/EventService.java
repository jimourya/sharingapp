package com.example.share.Service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.share.api.Event;
import com.example.share.api.Order;
import com.example.share.repositary.EventRepositary;
import com.example.share.repositary.OrderRepositary;

public class EventService {
	@Autowired
	private EventRepositary eventRepositary;
	private List<Event> l;


	public void addOrder(Event event) {
		// TODO Auto-generated method stub
		
	}

	public List<Event> getMasterEvent(String name) {
		// TODO Auto-generated method stub
		 l=new ArrayList<>();
		
		return l;
	}

	public Event getEvent(String name) {
		// TODO Auto-generated method stub
		return eventRepositary.findOne(name);
	} 
}
